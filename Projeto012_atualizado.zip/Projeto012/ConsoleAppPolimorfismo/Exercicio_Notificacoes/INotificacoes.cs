using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConsoleAppPolimorfismo.Exercicio_Notificacoes
{
    public interface INotificacoes
    {
        public void Enviar(string texto);
        
    }
}